import org.junit.Test;

import static io.restassured.RestAssured.given;
import static jdk.internal.net.http.common.Log.headers;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.isEmptyString;

public class Ecosure_ZSS{
    @Test
    public void AccountLookUp(){
        String endpoint = "http://test.cassavapaymentgateway.com/cpg-generic-endpoint/restapi/post-request";

        String body = """
                {
                "field1": "ZSS",
                "field2": "b36bd947b9e990fb794939e7d38bccee56fdb3e9ba36b7b8bc26de1bcc63c67d",
                "field3": "263772222077",
                "field7": "ECOSURE001",
                "field8": "ecosure",
                "field10": "1643200394765"
                }
                """;
        var response= given().body(body).when().post(endpoint).then();
        response.log().body();
        headers().
    assertThat().
                statusCode(200).
                header("Content-Type", equalTo("application/json;"));
    }
}
